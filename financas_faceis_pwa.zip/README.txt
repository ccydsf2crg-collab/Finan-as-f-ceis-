FINANÇAS FÁCEIS — PWA

Arquivos: index.html, manifest.json, sw.js e icon.svg.

Para instalar como app no iPhone:
1. Publique estes arquivos em uma hospedagem HTTPS.
2. Abra o endereço no Safari.
3. Compartilhar -> Adicionar à Tela de Início.

O armazenamento financeiro usa localStorage neste protótipo.
